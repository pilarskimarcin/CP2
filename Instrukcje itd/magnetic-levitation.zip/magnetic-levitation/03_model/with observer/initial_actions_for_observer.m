clear all; %close all;

%% load basic parameters
parameters_init

%% LQ calculation
linearization_for_observer

%% Normal simulation 
%initial values
z_initial = 20e-3;
v_initial = 0;
i_initial = 0;
initial_matrix = [i_initial; z_initial; v_initial];

%% Disturbance parameters
%change of resistance
R_change = 1.00;
%change of mass
m_change = 1.0;
m = m*m_change;

%% read LQ parameters
% fileID = fopen('LQ_parameters.txt', 'r');
% K_read = fscanf(fileID, '%f');
% Kz = K_read(1);
% Kv = K_read(2);
% Ki = K_read(3);
% Kzi = 0;
% fclose(fileID);

%% read LQI parameters
fileID = fopen('LQI_parameters.txt', 'r');
K_read = fscanf(fileID, '%f');
Kz = K_read(1);
Kv = K_read(2);
Ki = K_read(3);
Kzi = K_read(4);
fclose(fileID);

%% read SS parameters
fileID = fopen('SS_parameters.txt', 'r');
SS_read = fscanf(fileID, '%f');
% A matrix
A_size = 3;
k = 0;
for i=1:A_size
    for j=1:A_size
        A(j,i) = SS_read(i+j-1+k);
    end
    k = k+2;
end
% B matrix
B_size = 3;
for i=1:B_size
    B(i,1) = SS_read(A_size*A_size + i);
end
% C matrix
C_size_1 = 2;
C_size_2 = 3;
k = 0;
for i=1:C_size_1
    for j=1:C_size_2
        C(i,j) = SS_read(A_size*A_size+B_size + i+j-1+k);
    end
    k = k+2;
end
% D matrix
D_size = 2;
for i=1:D_size
    D(i,1) = SS_read(A_size*A_size+B_size+C_size_1*C_size_2 + i);
end
fclose(fileID);

%% Luenberger obsverver parameters
% gain matrix L
L = place(A',C',[-40 -50 -60]).';
disp('Luenberger correction matrix L eigenvalues are ')
eig(A-L*C)
%LQR gains (improved Q)
% Kz = -2660.8795;
% Kv = -117.9579;
% Ki = 11.0598;
% Q as eye(3)
% Kz = -303.2238;
% Kv = -7.7042;
% Ki = 1.3786;

%LQI gains
% Kz = -2740.3807;
% Kv = -118.4834;
% Ki = 11.066;
% Kzi = 1000;