clear all; %close all;

%% Initial required simulation parameters
g = 9.81;       % m/s^2
m = 58e-3;      % kg
bp = 0;         % air resistance
R_coil = 5.26;       % Ohm
U_supply = 12;  % V

%% Boundaries
z_min = 0;          % m
z_max = 20e-3;      % m

%% L(z) and L'(z) approximation parameters (based on identification)
a = 0.02062;
b = 343.5;
c = 0.1025;
d = 0.01301;
e = 54.59;

%% Current LUT
data_pts = [0 0.11 0.23 0.35 0.48 0.6 0.72 0.83 0.95 1.07 1.18 1.29 1.4 1.51 1.62 1.72 1.83 1.93 2.03 2.12 2.21];
arg_pts = 0:0.05:1;

%% Desire values
z_sp = 10e-3;                                                   % m
v_sp = 0;                                                       % m/s
i_sp = sqrt(-g*2*m/(- a*b*exp(-b*z_sp) - d*e*exp(-e*z_sp)));    % A

%not a state space x variable, but necessary
u_sp = R_coil*i_sp/U_supply;                                    % V

desired_matrix = [i_sp; z_sp; v_sp];

%% Disturbance
ExternalForce = 0.07;   % N
