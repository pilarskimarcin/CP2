function [] = parameters_fcn(ControllerType, OperationType)
%     arguments
%         ControllerType string {mustBeMember('LQ', 'LQI')}
%         OperationType string {mustBeMember('execution', 'linearization')}
%     end

    
    
    %% if chosen to linearize
    if (OperationType == "linearization")
        disp(' ');
        disp('*** <strong>Linearization begins</strong> ***');
        
        %%
        load('temp.mat')
        
        %%initial values
        z_initial = z_sp;
        v_initial = v_sp;
        i_initial = i_sp;
        
        %equilibrium point (punkt pracy)
        disp(['Linearization near equilibrium point' ...
            ': z = ' num2str(z_sp) ...
            ', v = ' num2str(v_sp), ...
            ', I = ' num2str(i_sp)]);
        disp(' ');
        
        op = findop('levitation_model');
        op.Inputs(1).u = u_sp;
        
        %linearization
        SC = linearize('levitation_model', op);
        [A,B,C,D] = ssdata(SC)
        
        %properties of linearized system
        %disp('Eigenvalues: ')
        Eig = eig(A);
        %disp('Controllability matrix: ')
        Q_c = ctrb(A,B);
        %disp('Observability matrix: ')
        Q_o = obsv(A,C);
        
        if (eig(A) < 0)
            disp('<strong>Asymptotic stability</strong> (type "Eig" for eigenvalues)')
        elseif (any(eig(A) == 0))
            disp('<strong>Stabke</strong> (type "Eig" for eigenvalues)')
        else
            disp('<strong>Not stable</strong> (type "Eig" for eigenvalues)')
        end
        
        if (rank(Q_c) == rank(A))
            disp('<strong>Controlable</strong> (type "Q_c" for controllability matrix)')
        else
            disp('<strong>Non-controlable</strong> (type "Q_c" for controllability matrix)')
        end
        
        if (rank(Q_o) == rank(A))
            disp('<strong>Observable</strong> (type "Q_o" for observability matrix)')
        else
            disp('<strong>Non-observable</strong>(type "Q_c" for observability matrix)')
        end
        disp(' ');
        
        %LQ calculations
        Q = diag(1./([0.1, 0.001, 0.01].^2));
        R = 1;
        [Klq,S,e] = lqr(A, B, Q, R);
        Ki_lq = Klq(1);
        Kz_lq = Klq(2);
        Kv_lq = Klq(3);
        disp(['<strong>LQ</strong> controller gains: '...
            'Ki = ' num2str(Klq(1)) ...
            ', Kz = ' num2str(Klq(2)) ...
            ', Kv = ' num2str(Klq(3))]);
        disp(' ');
        
        % LQI calculations
        Q = diag(1./([0.1, 0.001, 0.01, 0.001].^2));
        C = [0 1 0];
        [Klqi, Slqi, elqi] = lqi(ss(A,B,C,0),Q,R);
        Ki_lqi = Klqi(1);
        Kz_lqi = Klqi(2);
        Kv_lqi = Klqi(3);
        Kzi_lqi = Klqi(4);
        disp(['<strong>LQI</strong> controller gains: '...
            'Ki = ' num2str(Klqi(1)) ...
            ', Kz = ' num2str(Klqi(2)) ...
            ', Kv = ' num2str(Klqi(3)) ...
            ', Kzi = ' num2str(Klqi(4))]);
        
        disp('*** <strong>Linearization finished</strong> ***');
        disp(' ');
        
    %% if chosen to execute simulation
    elseif (OperationType == "execution")
        load('levitation_parameters')
        %initial values
        z_initial = 20e-3;
        v_initial = 0;
        i_initial = 0;
        %Current LUT
        data_pts = [0 0.11 0.23 0.35 0.48 0.6 0.72 0.83 0.95 1.07 1.18 1.29 1.4 1.51 1.62 1.72 1.83 1.93 2.03 2.12 2.21];
        arg_pts = 0:0.05:1;
        
        %% make some LQ controller gains
        if (ControllerType == "LQ")
            
            if (~exist('Kz_lq', 'var'))
                parameters_fcn('LQ', 'linearization')
            end
            clear all;
            load('levitation_parameters')
            Kz = Kz_lq;
            Kv = Kv_lq;
            Ki = Ki_lq;
            
        %% make some LQI controllers gain
        elseif (ControllerType == "LQI")
            
            if (~exist('Kz_lqi', 'var'))
                parameters_fcn('LQI', 'linearization')
            end
            clear all;
            load('levitation_parameters')
            Kz = Kz_lqi;
            Kv = Kv_lqi;
            Ki = Ki_lqi;
            Kzi = Kzi_lqi;
            
        end
    end
        
    save('levitation_parameters')
end