clear all
close all

%% load basic parameters
parameters_init

%% Linearization (comment this block if not running linearization)
disp(' ');
disp('*** <strong>Linearization begins</strong> ***');

%initial values
z_initial = z_sp;
v_initial = v_sp;
i_initial = i_sp;

%equilibrium point (punkt pracy)
disp(['Linearization near equilibrium point' ...
    ': z = ' num2str(z_sp) ...
    ', v = ' num2str(v_sp), ...
    ', I = ' num2str(i_sp)]);
disp(' ');

op = findop('levitation_model');
op.Inputs(1).u = u_sp;

%linearization
SC = linearize('levitation_model', op);
[A,B,C,D] = ssdata(SC);

%properties of linearized system
%disp('Eigenvalues: ')
Eig = eig(A);
%disp('Controllability matrix: ')
Q_c = ctrb(A,B);
%disp('Observability matrix: ')
Q_o = obsv(A,C);

if (eig(A) < 0)
    disp('<strong>Asymptotic stability</strong> (type "Eig" for eigenvalues)')
elseif (any(eig(A) == 0))
    disp('<strong>Stabke</strong> (type "Eig" for eigenvalues)')
else
    disp('<strong>Not stable</strong> (type "Eig" for eigenvalues)')
end

if (rank(Q_c) == rank(A))
    disp('<strong>Controlable</strong> (type "Q_c" for controllability matrix)')
else
    disp('<strong>Non-controlable</strong> (type "Q_c" for controllability matrix)')
end

if (rank(Q_o) == rank(A))
    disp('<strong>Observable</strong> (type "Q_o" for observability matrix)')
else
    disp('<strong>Non-observable</strong>(type "Q_c" for observability matrix)')
end
disp(' ');

%% save State-Space linearized model parameters

fileID = fopen('SS_parameters.txt', 'w');
fprintf(fileID,'%f\n%f\n%f\n%f\n', A, B, C, D);
fclose(fileID);

%% LQ calculations
% Q = eye(3);
Q = diag(1./([0.1, 0.001, 0.01].^2));
R = 1;
[K,S,P] = lqr(SC.a, SC.b, Q, R);
Ki = K(1);
Kz = K(2);
Kv = K(3);
disp(['<strong>LQ</strong> controller gains: '...
    'Ki = ' num2str(Ki) ...
    ', Kz = ' num2str(Kz) ...
    ', Kv = ' num2str(Kv)]);
disp(' ');

%% save LQ parameters

fileID = fopen('LQ_parameters.txt', 'w');
fprintf(fileID,'%f\n%f\n%f\n', Ki, Kz, Kv);
fclose(fileID);

%% LQI calculations
Q = diag(1./([0.1, 0.001, 0.01, 0.001].^2));
R = 1;
C = [0 1 0];
[Klqi, Slqi, elqi] = lqi(ss(A,B,C,0),Q,R);
Ki = Klqi(1);
Kz = Klqi(2);
Kv = Klqi(3);
Kzi = Klqi(4);
disp(['<strong>LQI</strong> controller gains: '... 
    'Ki = ' num2str(Ki) ...
    ', Kz = ' num2str(Kz) ...
    ', Kv = ' num2str(Kv) ...
    ', Kzi = ' num2str(Kzi)]);

%% save LQI parameters

fileID = fopen('LQI_parameters.txt', 'w');
fprintf(fileID,'%f\n%f\n%f\n%f\n', Ki, Kz, Kv, Kzi);
fclose(fileID);

%% 
disp('*** <strong>Linearization finished</strong> ***');
disp(' ');


%% read LQ parameters
% fileID = fopen('LQ_parameters.txt', 'r');
% K_read = fscanf(fileID, '%f');
% Ki = K_read(1);
% Kz = K_read(2);
% Kv = K_read(3);
% fclose(fileID);

%% read LQI parameters
% fileID = fopen('LQI_parameters.txt', 'r');
% K_read = fscanf(fileID, '%f');
% Ki = K_read(1);
% Kz = K_read(2);
% Kv = K_read(3);
% Kzi = K_read(4);
% fclose(fileID);
