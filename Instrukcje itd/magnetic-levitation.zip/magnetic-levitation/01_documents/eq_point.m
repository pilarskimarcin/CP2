disp(' ')
disp('********************************************************************')
disp('Call the "plant_identification.m" script befor using this M-file.')
disp('********************************************************************')
disp(' ')

%% Equilibrium point determination (corresponding to a desired operational point)
% An equilibrium point corresponding to a given (set, desired, reference)
% ball position can be found analitically by equating RHS-s of state-space
% equations to zero.
% z_ep = 0.010 % m % Desired (set) position of the ball at the equilibrium point.
% v_ep = 0 % m/s
% % L_ep = feval(fitObject,z_ep)
% L_ep = ind.a*exp(-ind.b*z_ep) + ind.c + ind.d*exp(-ind.e*z_ep)
% % L_d_ep = differentiate(fitObject, z_ep)
% L_d_ep = -ind.a*ind.b*exp(-ind.b*z_ep) - ind.d*ind.e*exp(-ind.e*z_ep)
% % [~, L_d_ep] = differentiate(fitObject, z_ep)
% L_dd_ep = ind.a*ind.b^2*exp(-ind.b*z_ep) + ind.d*ind.e^2*exp(-ind.e*z_ep)
% i_ep = sqrt(-2*m_b*g_E/L_d_ep)
% u_ep = R_n * i_ep
% % w_ep = u_ep/E_ps

%% Plant model linearization at the equilibrium point
% Analitycal method, closed-form solution:
% A = [0, 1, 0
%     1/2/m_b*L_dd_ep*i_ep^2, -b_v/m_b, 1/m_b*L_d_ep*i_ep
%     (1/L_ep*L_d_ep^2 - 1/L_ep^2*L_dd_ep^2)*v_ep*i_ep, ...
%     -1/L_ep*L_d_ep*i_ep, -1/L_ep*L_d_ep*v_ep - R_n/L_ep]
% B = [0; 0; 1/L_ep]
% C = [1 0 0; 0 0 1]
% D = [0; 0]

%% Operating point partial specification
z_ep = 0.010 % m % Desired (set) position of the ball at the equilibrium point.
v_ep = 0

%% Initial condition (IC)
% The following variables must be set before using a Simulink model of the
% plant because the variables are entered in masks (dialog windows) of
% Integrators in the model. 
z_ic = z_ep % m
v_ic = v_ep % m/s
% i_ic = i_ep % A
i_ic = 1

%% Operational point (equilibrium point) determination
% Numerical method based on a Simulink model of the plant.
% Looking for an equilibrium point (operational point)
% corresponding to given ball position and ball velocity.
%
% Obtaining a preliminary specification of the operating point (based on the
% simulin model).
os = operspec('plant_model_for_linearisation');
% Modifying the specification according to our needs - deciding what is
% known and should be fixed, and what is unknown and should be computed.
os.Inputs(1).u = 6; % Just an initial guess for an iterative numerical search procedure - we do not now an exact value.
os.Inputs(1).Min = 0;
os.Inputs(1).Max = E_ps;
os.Inputs(1).Known = false; % We do not know an exact value.
os.States(1).x = [z_ep; v_ep]; % Exact values are known.
os.States(1).Known = [true; true]; % We know exactly values of these two state space variables at the desired equilibrium point.
os.States(2).x = 1; % Just an initial guess.
os.States(2).Known = false; % We do not know an exact value.
os.States(2).Min = 0;
os.States(2).Max = E_ps/R_n;
os.Outputs(1).y = z_ep;
os.Outputs(1).Known = true;
os.Outputs(2).y = 1;
os.Outputs(2).Known = false;
os.Outputs(2).Min = 0;
os.Outputs(2).Max = E_ps/R_n
% Computing the operating point based on the simulink model and the
% specification.
op = findop('plant_model_for_linearisation',os)
% Extracting computed values of the winding current and control signal at
% the equilibrium point:
i_ep = op.States(2).x;
u_ep = op.Inputs(1).u;

%% Setting an equilibrium point (if it is known)
% op = operpoint('plant_model_for_linearisation')
% op.States(1).x(1) = z_ep
% op.States(1).x(2) = v_ep
% op.States(2).x = i_ep
% op.Inputs(1).u = u_ep

%% Plant model linearisation
% Numerical methods, based on a Simulink model of the plant and an
% equilibrium point specification.
se = linearize('plant_model_for_linearisation', op)
% Extracting state space matrices:
A = se.a
B = se.b
C = se.c
D = se.d
% Extracting state space matrices (another method):
[A,B,C,D] = ssdata(se)
% clear os op se

%% State space equations properties
% Eigenvalues of the state matrix:
eig(A)
% Controllability matrix:
Q_c = ctrb(A,B)
% for k = 1:3,
%     Q_c_n(:,k) = Q_c(:,k)/norm(Q_c(:,k))
% end
rank(Q_c)
cond(Q_c)
% Observability matrix:
Q_o = obsv(A,C)
rank(Q_o)
cond(Q_o)

%% LQ adn LQI controllers design
% Weight matrices for a performance index:
% Q = eye(1)
% An element on the main diagonal of the Q weight matrix may be selected
% equal to an invers of a square of an acceptable variance or error value
% of a state space variable.
Q = diag(1./([0.001, 0.01, 0.1].^2))
R = 1000
% LQ controller gain matrix:
K_lq = lqr(A,B,Q,R)
Qi = Q
Qi(4,4) = 1e10
Ri = R
% LQI controller gain matrix:
K_lqi = lqi(ss(A,B,[-1,0,0],0),Qi,Ri);

%% Nyquist plots of open loops comprising plants and controllers
S = ss(A,B,K_lq,0)
% S = ss(A,B,[1,0,0],0)
G = tf(S)
Ai = A;
Ai(4,1) = 1;
Ai(4,4) = 0
Bi = B;
Bi(4,1) = 0
Si = ss(Ai,Bi,K_lqi,0);
Gi = tf(Si);
figure
no = nyquistoptions;
no.ShowFullContour = 'off';
nyquist(G,no)
hold on
nyquist(Gi,no)
clear no

%% Closed-loop system simulation
z_ic = 0.0125
% closed_loop_lq_controller
% closed_loop_lqi_controller
% closed_loop_lqi_and_lqila_controllers.slx